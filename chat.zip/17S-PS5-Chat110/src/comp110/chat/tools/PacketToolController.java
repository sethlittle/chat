package comp110.chat.tools;

import comp110.chat.packets.Connection;
import comp110.chat.packets.ConnectionObserver;
import comp110.chat.packets.Packet;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ListView;

public class PacketToolController implements ConnectionObserver {

	private Connection _connection;
	@FXML
	private TextField _packetField;
	@FXML
	private ListView<Packet> _sent, _received;

	public PacketToolController(Connection connection) {
		_connection = connection;
		_connection.addObserver(this);
	}

	public void packetSent(Packet packet) {
		_sent.getItems().add(packet);
		_sent.scrollTo(packet);
	}

	public void packetReceived(Packet packet) {
		_received.getItems().add(packet);
		_received.scrollTo(packet);
	}

	public void send() {
		Packet packet = new Packet(_packetField.getText());
		_packetField.setText("");
		_connection.send(packet);
	}

}
