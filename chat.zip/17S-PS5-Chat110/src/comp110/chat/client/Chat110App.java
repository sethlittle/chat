package comp110.chat.client;

import comp110.chat.tools.PacketToolWindow;
import comp110.chat.packets.Connection;
import comp110.chat.packets.Packet;
import javafx.application.Application;
import javafx.stage.Stage;

public class Chat110App extends Application {
	public static void main(String[] args) {
		Application.launch();
	}

	public void start(Stage stage) throws Exception {

		Connection connection = new Connection();
		connection.connect("ws://comp110.com/chat110");

		// TODO: Once our app is working, we'll remove this
		// PacketToolWindow packets = new PacketToolWindow(connection);

		// TODO: Construct the Coordinator
		Coordinator coordinator = new Coordinator(connection);
		connection.send(new Packet("auth:sethl:1a26946d09e43b2c"));
		connection.send(new Packet("who"));

	}
}
