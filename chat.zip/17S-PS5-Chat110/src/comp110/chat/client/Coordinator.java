package comp110.chat.client;

import comp110.chat.packets.ConnectionObserver;
import comp110.chat.packets.Packet;
import comp110.chat.packets.Connection;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class Coordinator implements ConnectionObserver {

	private Connection _connection;
	private FriendsWindow _friends;
	public static final String WHO = "who";
	public static final String DM = "dm";
	private Map<String, ChatWindow> _chats;

	public Coordinator(Connection connection) {
		_connection = connection;
		_connection.addObserver(this);
		_friends = new FriendsWindow(this);
		_chats = new HashMap<String, ChatWindow>();
	}

	public void packetSent(Packet packet) {
		if (packet.getType().equals(WHO)) {
			this.handleWho(packet);
		}
		if (packet.getType().equals(DM)) {
			this.handleDMSent(packet);
		}
	}

	public void packetReceived(Packet packet) {
		if (packet.getType().equals(WHO)) {
			this.handleWho(packet);
		}
		if (packet.getType().equals(DM)) {
			this.handleDMReceived(packet);
		}
	}

	private void handleWho(Packet packet) {
		List<String> onyens = new ArrayList<String>();
		for (int i = 0; i < packet.size(); i++) {
			onyens.add(packet.getParameter(i));
		}
		_friends.update(onyens);
	}

	public void refresh() {
		_connection.send(new Packet("who"));
	}

	public void send(String onyen, String text) {
		_connection.send(new Packet("dm:" + onyen + ":" + text));
	}

	private ChatWindow getChatWindow(String onyen) {
		ChatWindow chat = _chats.get(onyen);
		if (chat == null) {
			chat = new ChatWindow(onyen, this);
			_chats.put(onyen, chat);
		}
		chat.show();
		return chat;
	}

	private void handleDMReceived(Packet packet) {
		String onyen = packet.getParameter(0);
		String text = packet.join(1);
		this.getChatWindow(onyen).addHistory(onyen + ": " + text);
	}

	private void handleDMSent(Packet packet) {
		String onyen = packet.getParameter(0);
		String text = packet.join(1);
		this.getChatWindow(onyen).addHistory("You: " + text);
	}

	public void showChatWindow(String onyen) {
		this.getChatWindow(onyen);
	}
}
